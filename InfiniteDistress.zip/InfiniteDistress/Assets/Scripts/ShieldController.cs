﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShieldController : MonoBehaviour
{
    
    Rigidbody2D RB;
    float speed = 100;

    public Animator A;
    bool shift = true;

    // Start is called before the first frame update
    void Start()
    {
        RB = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {
        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");

        RB.AddForce(new Vector2(x * speed, y * speed));

        if (Mathf.Abs(RB.velocity.magnitude) < 3 && shift) { A.SetTrigger("Shift"); shift = false; }
        if (Mathf.Abs(RB.velocity.magnitude) > 3) { shift = true;  }
    }
}
