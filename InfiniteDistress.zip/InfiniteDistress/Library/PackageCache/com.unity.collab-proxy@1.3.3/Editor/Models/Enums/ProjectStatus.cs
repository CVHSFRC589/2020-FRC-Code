namespace Unity.Cloud.Collaborate.Models.Enums
{
    internal enum ProjectStatus
    {
        Unbound,
        Bound,
        Loading,
        Ready
    }
}
