using UnityEditor;

namespace Unity.Cloud.Collaborate.Tests
{
    internal class TestWindow : EditorWindow
    {
    }
}
